$(function () {
    var topHeight = $('header').outerHeight();
    $(".dummy--header").css('height', topHeight);
    console.log('loaded');

    $('[data-path]').each(function () {
        var totPaths = parseInt($(this).attr('data-path'), 10),
            i = 0;
        for (var i = 1; i < totPaths + 1; i++) {
            $(this).append('<span class="path' + i + '"></span>');
        }
    });

    $('#why-choose-us').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        speed: 1000,
        autoplaySpeed: 5000,
        infinite: true,
        arrows: true,
    });


    const accordionItemHeaders = document.querySelectorAll(".accordion-item-header");

    accordionItemHeaders.forEach(accordionItemHeader => {
        accordionItemHeader.addEventListener("click", event => {

            // Uncomment in case you only want to allow for the display of only one collapsed item at a time!

            const currentlyActiveAccordionItemHeader = document.querySelector(".accordion-item-header.active");
            if (currentlyActiveAccordionItemHeader && currentlyActiveAccordionItemHeader !== accordionItemHeader) {
                currentlyActiveAccordionItemHeader.classList.toggle("active");
                currentlyActiveAccordionItemHeader.nextElementSibling.style.maxHeight = 0;
            }

            accordionItemHeader.classList.toggle("active");
            const accordionItemBody = accordionItemHeader.nextElementSibling;
            if (accordionItemHeader.classList.contains("active")) {
                accordionItemBody.style.maxHeight = accordionItemBody.scrollHeight + "px";
            }
            else {
                accordionItemBody.style.maxHeight = 0;
            }

        });
    });
});
/* ---------- document ready end ---------- */
